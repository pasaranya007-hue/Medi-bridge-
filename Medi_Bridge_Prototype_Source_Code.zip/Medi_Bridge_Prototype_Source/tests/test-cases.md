# Manual Test Cases

1. Open `index.html`: sample dashboard appears.
2. Submit blank required fields: browser blocks submission.
3. Submit fictional centre and location: new Pending case appears.
4. Click Mark acknowledged: status updates.
5. Verify summary counters change.
6. Open on mobile: layout stacks vertically.
7. Enter HTML-like text: displayed text is escaped.
