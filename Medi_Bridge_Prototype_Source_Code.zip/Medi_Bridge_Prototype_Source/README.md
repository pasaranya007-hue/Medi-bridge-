# Medi-Bridge Prototype

A front-end demo of accident case reporting and hospital–police coordination.

## Run
1. Download and extract this project.
2. Open `index.html` in a modern browser.
3. Use fictional details to create a demo report.
4. Click `Mark acknowledged` to simulate an acknowledgement.

## Features
- Demo accident report form
- Sample case dashboard and status updates
- Urgency labels and summary counters
- Responsive layout for mobile/desktop

## Limitations and safety
This is a front-end demonstration only. It does not connect to real hospitals, police, GPS, insurers, or official medico-legal systems. It has no backend or production security. Do not enter real patient information.
