# Technical Design

Architecture: Browser UI (HTML/CSS) → JavaScript client-side state → dashboard table.

Workflow: user enters fictional report details; browser validates required fields; JavaScript creates a demo case; dashboard shows Pending; acknowledgement button changes status locally.

Not implemented: backend/database, login, GPS geofencing, official certificate generation, external alerts, or real hospital/police integrations. A production version requires security review, authorized integrations, audit logs, legal review, and stakeholder testing.
